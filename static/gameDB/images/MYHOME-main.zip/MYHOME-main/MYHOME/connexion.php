<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "myhome";

$conn = new mysqli($servername, $username, $password, $database);
?>