<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/ab021e0629.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="signup_login.css"> 
    <link rel="stylesheet" href="nav_footer/style_nav.css"> 
    <title>Document</title>
</head>
<body>
<?php include "../MYHOME/nav_footer/navbar.php"?>

    <main>
        <div id="container">
            <div>
                
            </div>

            <div>

            </div>
        </div>
    </main>
</body>
</html>