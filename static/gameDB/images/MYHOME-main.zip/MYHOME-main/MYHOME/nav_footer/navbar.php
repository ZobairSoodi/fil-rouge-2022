<nav>
        <div>
            <a href="home.php">Home</a>
            <a href="houses.php">Houses</a>
            <a id="logo" href="">MY<span>HOME</span></a>
            <a href="">About us</a>
            <a href="galary.php">Galary</a>
            <div>
                <a href="" id="favourit"><img src="images/Favorite.png"></a>
                <a href=""><img src="images/user.png"></a>
            </div>
        </div>
        <section></section>
     </nav>

