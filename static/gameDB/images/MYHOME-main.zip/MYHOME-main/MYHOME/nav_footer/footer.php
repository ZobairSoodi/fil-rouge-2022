<footer>
            <div id="footer_information">
                <div id="logo_footer">
                    <h3><span>MY</span>HOME</h3>
                </div>
                <div class="formation">
                    <span>ABOUT</span>
                    <span>CONTACT</span>
                    <span>HOME</span>
                </div>
                <div class="footer_icon">
                    <ul>
                         <i class="fa-brands fa-instagram"></i>
                         <i class="fa-brands fa-linkedin-in"></i>
                         <i class="fa-brands fa-facebook"></i>
                    </ul>
                </div>
            </div>
            <div id="footer_div2">
                 <h5>©MYHOME2022</h5>
            </div>
        </footer>